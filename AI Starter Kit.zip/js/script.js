// AI Anime Creator Starter Kit - Main JavaScript

class AnimeCreatorApp {
    constructor() {
        this.currentPage = 1;
        this.totalPages = 20;
        this.pages = {};
        this.init();
    }

    init() {
        this.loadPages();
        this.setupNavigation();
        this.setupEventListeners();
        this.showPage(1);
    }

    loadPages() {
        // Define all 20 pages content
        this.pages = {
            1: {
                title: "HALAMAN 1 — INTRO",
                content: `
                    <h2>HALAMAN 1 — INTRO</h2>
                    <p>Selamat datang di AI Anime Creator Starter Kit.</p>
                    <p>Produk ini dibuat khusus untuk:</p>
                    <ul>
                        <li>Pemula yang suka anime</li>
                        <li>Tidak bisa menggambar</li>
                        <li>Ingin bikin konten anime sendiri</li>
                        <li>Ingin monetisasi karya digital secara AMAN</li>
                    </ul>
                    <div class="success-box">
                        <h4>Kamu TIDAK butuh:</h4>
                        <ul>
                            <li>❌ Skill gambar</li>
                            <li>❌ Laptop mahal</li>
                            <li>❌ Software ribet</li>
                        </ul>
                    </div>
                    <div class="important-box">
                        <h4>Yang kamu butuhkan cuma:</h4>
                        <ul>
                            <li>✔️ HP / laptop</li>
                            <li>✔️ Internet</li>
                            <li>✔️ AI gratis</li>
                        </ul>
                    </div>
                `
            },
            2: {
                title: "HALAMAN 2 — KONSEP DASAR",
                content: `
                    <h2>HALAMAN 2 — KONSEP DASAR</h2>
                    <p>Anime AI = gambar anime yang dibuat oleh AI berdasarkan prompt (teks).</p>
                    <p>AI tidak mencuri gambar. AI membuat gambar BARU dari deskripsi kamu.</p>
                    <div class="content-box">
                        <h3>Kunci hasil bagus:</h3>
                        <ol>
                            <li>Prompt jelas</li>
                            <li>Style konsisten</li>
                            <li>Detail terarah</li>
                        </ol>
                    </div>
                `
            },
            3: {
                title: "HALAMAN 3 — TOOLS AI GRATIS",
                content: `
                    <h2>HALAMAN 3 — TOOLS AI GRATIS</h2>
                    <h3>Rekomendasi tools:</h3>
                    <div class="prompt-card">
                        <h4>1️⃣ Bing Image Creator (DALL·E)</h4>
                        <p>Gratis dengan akun Microsoft, hasil berkualitas tinggi</p>
                    </div>
                    <div class="prompt-card">
                        <h4>2️⃣ Leonardo AI</h4>
                        <p>Banyak preset anime, kredit harian gratis</p>
                    </div>
                    <div class="prompt-card">
                        <h4>3️⃣ Playground AI</h4>
                        <p>Mudah digunakan, komunitas aktif</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips:</h4>
                        <ul>
                            <li>Gunakan rasio 1:1 atau 4:5</li>
                            <li>Pilih style anime / illustration</li>
                        </ul>
                    </div>
                `
            },
            4: {
                title: "HALAMAN 4 — STRUKTUR PROMPT ANIME",
                content: `
                    <h2>HALAMAN 4 — STRUKTUR PROMPT ANIME</h2>
                    <h3>Rumus prompt sederhana:</h3>
                    <div class="code-block">
                        [Gender + umur] [warna rambut + gaya rambut] [ekspresi wajah] [pakaian] [style anime] [latar belakang] [kualitas]
                    </div>
                    <div class="content-box">
                        <h3>Contoh Prompt:</h3>
                        <p>"anime girl, 18 years old, long purple hair, confident smile, futuristic jacket, cyberpunk anime style, neon background, ultra detailed"</p>
                    </div>
                `
            },
            5: {
                title: "HALAMAN 5 — 30 PROMPT ANIME ORIGINAL",
                content: `
                    <h2>🎨 HALAMAN 5 — 30 PROMPT ANIME ORIGINAL</h2>
                    
                    <h3>1–10 | Karakter Utama</h3>
                    ${this.generatePromptCards([
                        "Original anime boy, silver hair, cyberpunk hoodie, neon city night, cinematic lighting, sharp eyes, highly detailed, anime style",
                        "Original anime girl, long black hair, red kimono modern style, cherry blossom background, soft lighting, elegant anime art",
                        "Anime warrior female, short white hair, futuristic armor, glowing blue sword, dynamic pose, epic anime illustration",
                        "Anime male mage, dark cloak, floating magic circle, mystical atmosphere, fantasy anime art",
                        "Anime school girl original, pastel uniform, sunset classroom window, soft color palette",
                        "Anime street fighter, messy hair, bandaged hands, urban alley, dramatic shadows",
                        "Anime demon hunter, black coat, red glowing eyes, dark fantasy background",
                        "Anime elf girl original, emerald eyes, forest light rays, fantasy anime style",
                        "Anime cyber ninja, neon katana, rain city, high contrast lighting",
                        "Anime samurai original, traditional armor, sunset battlefield, cinematic anime art"
                    ])}
                    
                    <h3>11–20 | Style Unik & Mood</h3>
                    ${this.generatePromptCards([
                        "Anime character portrait, minimalist background, clean line art, soft shading",
                        "Dark anime style character, gothic outfit, moonlight, dramatic anime illustration",
                        "Cute anime chibi original, oversized eyes, pastel colors, simple background",
                        "Anime steampunk character, goggles, mechanical arm, warm lighting",
                        "Anime fantasy healer, white robe, glowing green magic, peaceful atmosphere",
                        "Anime villain original, cold expression, purple aura, dramatic lighting",
                        "Anime sci-fi pilot, futuristic helmet, space background",
                        "Anime post-apocalyptic survivor, torn clothes, dust storm, cinematic scene",
                        "Anime royal character, elegant outfit, palace interior, soft golden light",
                        "Anime fire user, flames swirling, intense action pose"
                    ])}
                    
                    <h3>21–30 | Siap Jual (Stock / Konten)</h3>
                    ${this.generatePromptCards([
                        "Anime profile avatar, clean background, centered face, high detail",
                        "Anime character full body, neutral pose, plain background, commercial use",
                        "Anime illustration no text, balanced composition, professional quality",
                        "Anime character for poster, dramatic pose, empty space background",
                        "Anime wallpaper style, wide composition, atmospheric lighting",
                        "Anime character concept art, turn-around pose, design focus",
                        "Anime fantasy couple original, emotional mood, soft lighting",
                        "Anime futuristic city with character, depth of field, cinematic look",
                        "Anime character with pet creature, fantasy companion",
                        "Anime original hero, iconic pose, epic lighting, masterpiece anime art"
                    ])}
                    
                    <div class="important-box">
                        <h4>🔒 Tambahan Biar AMAN & LULUS REVIEW</h4>
                        <p>Tambahkan di akhir prompt:</p>
                        <div class="code-block">
                            original character, no fanart, no copyrighted character, commercial use allowed
                        </div>
                    </div>
                `
            },
            6: {
                title: "HALAMAN 6 — KONSISTENSI KARAKTER",
                content: `
                    <h2>HALAMAN 6 — KONSISTENSI KARAKTER</h2>
                    <p>Agar wajah tidak berubah:</p>
                    <div class="success-box">
                        <h4>Tips Konsistensi:</h4>
                        <ol>
                            <li>Gunakan deskripsi rambut & mata sama</li>
                            <li>Gunakan style yang sama</li>
                            <li>Jangan ganti terlalu banyak detail</li>
                            <li>Simpan prompt favorit kamu</li>
                        </ol>
                    </div>
                `
            },
            7: {
                title: "HALAMAN 7 — IDE KONTEN",
                content: `
                    <h2>HALAMAN 7 — IDE KONTEN</h2>
                    <h3>Konten yang bisa dibuat:</h3>
                    <div class="prompt-card">
                        <h4>Wallpaper anime</h4>
                        <p>Background untuk HP dan desktop dengan tema anime</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Quote anime original</h4>
                        <p>Quotes motivasi dengan ilustrasi anime</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Karakter brand</h4>
                        <p>Mascot untuk bisnis atau personal branding</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Story IG / Telegram</h4>
                        <p>Konten visual untuk social media</p>
                    </div>
                `
            },
            8: {
                title: "HALAMAN 8 — MONETISASI AMAN",
                content: `
                    <h2>HALAMAN 8 — MONETISASI AMAN</h2>
                    <h3>Cara cuan TANPA melanggar copyright:</h3>
                    <div class="success-box">
                        <h4>✅ BOLEH:</h4>
                        <ul>
                            <li>✔️ Jual wallpaper original</li>
                            <li>✔️ Jual prompt</li>
                            <li>✔️ Jual template</li>
                            <li>✔️ Jual jasa custom character</li>
                            <li>✔️ Konten + affiliate</li>
                        </ul>
                    </div>
                    <div class="warning-box">
                        <h4>❌ JANGAN:</h4>
                        <ul>
                            <li>❌ Jual anime resmi</li>
                            <li>❌ Jual karakter terkenal</li>
                        </ul>
                    </div>
                `
            },
            9: {
                title: "HALAMAN 9 — STRATEGI TELEGRAM",
                content: `
                    <h2>HALAMAN 9 — STRATEGI TELEGRAM</h2>
                    <h3>Pola posting:</h3>
                    <div class="prompt-card">
                        <h4>1. Edukasi</h4>
                        <p>Bagikan tips dan tutorial AI anime</p>
                    </div>
                    <div class="prompt-card">
                        <h4>2. Visual anime</h4>
                        <p>Tampilkan hasil karya yang menarik</p>
                    </div>
                    <div class="prompt-card">
                        <h4>3. Story</h4>
                        <p>Cerita di balik pembuatan karakter</p>
                    </div>
                    <div class="prompt-card">
                        <h4>4. Soft selling</h4>
                        <p>Perkenalan produk secara natural</p>
                    </div>
                    <div class="prompt-card">
                        <h4>5. Hard selling</h4>
                        <p>Penawaran langsung dengan diskon</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips Penting:</h4>
                        <p>Pin produk di atas channel untuk visibility maksimal</p>
                    </div>
                `
            },
            10: {
                title: "HALAMAN 10 — PENUTUP",
                content: `
                    <h2>HALAMAN 10 — PENUTUP</h2>
                    <p>Kalau kamu konsisten:</p>
                    <div class="success-box">
                        <h4>Hasil yang akan kamu dapatkan:</h4>
                        <ul>
                            <li>Skill akan naik</li>
                            <li>Konten akan rapi</li>
                            <li>Peluang cuan terbuka</li>
                        </ul>
                    </div>
                    <div class="content-box">
                        <h3>Pesan Terakhir:</h3>
                        <p>Anime bukan cuma hiburan. Sekarang bisa jadi aset digital.</p>
                        <p style="font-size: 1.5em; text-align: center; margin-top: 20px;">🚀 Selamat berkarya 🚀</p>
                    </div>
                `
            },
            11: {
                title: "HALAMAN 11 — PROMPT VARIASI STYLE",
                content: `
                    <h2>HALAMAN 11 — PROMPT VARIASI STYLE</h2>
                    <p>Gunakan variasi style untuk eksplor:</p>
                    <div class="prompt-card">
                        <h4>cinematic anime lighting</h4>
                        <p>Pencahayaan sinematik seperti film anime</p>
                    </div>
                    <div class="prompt-card">
                        <h4>soft pastel anime illustration</h4>
                        <p>Warna lembut dan pastel yang menenangkan</p>
                    </div>
                    <div class="prompt-card">
                        <h4>dark fantasy anime style</h4>
                        <p>Gaya gelap dengan nuansa fantasi</p>
                    </div>
                    <div class="prompt-card">
                        <h4>cyberpunk anime neon</h4>
                        <p>Gaya futuristik dengan efek neon</p>
                    </div>
                    <div class="prompt-card">
                        <h4>clean anime lineart</h4>
                        <p>Garis bersih dan minimalis</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips:</h4>
                        <p>Tambahkan di akhir prompt untuk hasil berbeda</p>
                    </div>
                `
            },
            12: {
                title: "HALAMAN 12 — NEGATIVE PROMPT (PENTING)",
                content: `
                    <h2>HALAMAN 12 — NEGATIVE PROMPT (PENTING)</h2>
                    <p>Agar hasil lebih rapi, tambahkan:</p>
                    <div class="code-block">
                        "blurry, low quality, deformed face, extra fingers, bad anatomy, watermark, text"
                    </div>
                    <div class="content-box">
                        <h3>Mengapa Negative Prompt Penting?</h3>
                        <p>Negative prompt membantu AI menghindari error umum seperti:</p>
                        <ul>
                            <li>Wajah yang blur atau tidak fokus</li>
                            <li>Kualitas gambar yang rendah</li>
                            <li>Wajah yang deformasi atau aneh</li>
                            <li>Jari yang berlebih atau salah</li>
                            <li>Anatomi tubuh yang tidak benar</li>
                            <li>Watermark atau teks yang tidak diinginkan</li>
                        </ul>
                    </div>
                `
            },
            13: {
                title: "HALAMAN 13 — SETTING DASAR",
                content: `
                    <h2>HALAMAN 13 — SETTING DASAR (JIKA ADA)</h2>
                    <p>Jika tool menyediakan setting:</p>
                    <div class="prompt-card">
                        <h4>Quality: High</h4>
                        <p>Gunakan kualitas tertinggi untuk hasil terbaik</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Guidance / Prompt Strength: Medium</h4>
                        <p>Set sedang untuk keseimbangan antara prompt dan kreativitas AI</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Resolution: 1024x1024</h4>
                        <p>Resolusi standar untuk kualitas yang baik</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips:</h4>
                        <p>Jangan ubah terlalu ekstrem di awal. Mulai dengan setting standar dulu.</p>
                    </div>
                `
            },
            14: {
                title: "HALAMAN 14 — WORKFLOW CEPAT",
                content: `
                    <h2>HALAMAN 14 — WORKFLOW CEPAT</h2>
                    <p>Alur paling efisien:</p>
                    <div class="content-box">
                        <h3>Langkah 1: Tentukan karakter</h3>
                        <p>Bayangkan karakter yang ingin kamu buat: gender, umur, gaya rambut, ekspresi</p>
                    </div>
                    <div class="content-box">
                        <h3>Langkah 2: Tulis prompt utama</h3>
                        <p>Gunakan rumus prompt yang sudah dipelajari</p>
                    </div>
                    <div class="content-box">
                        <h3>Langkah 3: Generate 3–4 gambar</h3>
                        <p>Buat beberapa variasi untuk pilihan</p>
                    </div>
                    <div class="content-box">
                        <h3>Langkah 4: Pilih terbaik</h3>
                        <p>Pilih gambar yang paling sesuai dengan visi kamu</p>
                    </div>
                    <div class="content-box">
                        <h3>Langkah 5: Simpan prompt final</h3>
                        <p>Catat prompt yang berhasil untuk penggunaan kembali</p>
                    </div>
                    <div class="success-box">
                        <h4>Tips:</h4>
                        <p>Ulangi proses ini untuk konsistensi karakter</p>
                    </div>
                `
            },
            15: {
                title: "HALAMAN 15 — IDE PRODUK DIGITAL",
                content: `
                    <h2>HALAMAN 15 — IDE PRODUK DIGITAL</h2>
                    <h3>Produk yang bisa kamu jual:</h3>
                    <div class="prompt-card">
                        <h4>Wallpaper anime pack</h4>
                        <p>Kumpulan wallpaper anime tema tertentu</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Prompt pack</h4>
                        <p>Kumpulan prompt siap pakai untuk berbagai style</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Character pack</h4>
                        <p>Kumpulan karakter anime dengan tema konsisten</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Template quote anime</h4>
                        <p>Template siap pakai dengan placeholder text</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Jasa custom karakter</h4>
                        <p>Layanan pembuatan karakter sesuai permintaan klien</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips:</h4>
                        <p>Mulai dari yang PALING simpel dulu, lalu berkembang ke produk yang lebih kompleks</p>
                    </div>
                `
            },
            16: {
                title: "HALAMAN 16 — HARGA UNTUK PEMULA",
                content: `
                    <h2>HALAMAN 16 — HARGA UNTUK PEMULA</h2>
                    <h3>Contoh harga aman:</h3>
                    <div class="prompt-card">
                        <h4>Wallpaper pack: 15K–29K</h4>
                        <p>Terjangkau untuk pemula, mudah dijual</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Prompt pack: 29K–49K</h4>
                        <p>Nilai tambah tinggi, bisa dijual berulang</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Custom karakter: 25K–75K</h4>
                        <p>Harga fleksibel sesuai kompleksitas</p>
                    </div>
                    <div class="success-box">
                        <h4>Strategi Harga:</h4>
                        <p>Naikkan harga seiring kualitas dan reputasi kamu meningkat</p>
                    </div>
                `
            },
            17: {
                title: "HALAMAN 17 — PLATFORM JUALAN",
                content: `
                    <h2>HALAMAN 17 — PLATFORM JUALAN</h2>
                    <h3>Rekomendasi platform:</h3>
                    <div class="prompt-card">
                        <h4>Trakteer</h4>
                        <p>Platform kreator Indonesia, dukungan lokal yang baik</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Gumroad</h4>
                        <p>Platform internasional, cocok untuk produk digital</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Telegram Channel</h4>
                        <p>Direct selling ke komunitas, interaktif</p>
                    </div>
                    <div class="prompt-card">
                        <h4>Instagram DM</h4>
                        <p>Personal selling, build relationship dengan klien</p>
                    </div>
                    <div class="important-box">
                        <h4>Tips:</h4>
                        <p>Fokus 1 platform dulu sampai stabil, baru ekspansi ke platform lain</p>
                    </div>
                `
            },
            18: {
                title: "HALAMAN 18 — KESALAHAN UMUM",
                content: `
                    <h2>HALAMAN 18 — KESALAHAN UMUM</h2>
                    <h3>Hindari kesalahan ini:</h3>
                    <div class="warning-box">
                        <h4>❌ Kesalahan Fatal:</h4>
                        <ul>
                            <li>❌ Pakai karakter anime terkenal</li>
                            <li>❌ Ganti style terlalu sering</li>
                            <li>❌ Jual sebelum siap</li>
                            <li>❌ Tidak simpan prompt</li>
                        </ul>
                    </div>
                    <div class="success-box">
                        <h4>✅ Prinsip Sukses:</h4>
                        <ul>
                            <li>Main aman & konsisten</li>
                            <li>Bangun portfolio dulu</li>
                            <li>Pelajari dari feedback</li>
                            <li>Tingkatkan kualitas bertahap</li>
                        </ul>
                    </div>
                `
            },
            19: {
                title: "HALAMAN 19 — CHECKLIST MULAI",
                content: `
                    <h2>HALAMAN 19 — CHECKLIST MULAI</h2>
                    <div class="checklist">
                        <ul>
                            <li onclick="this.classList.toggle('checked')">☐ Tentukan niche anime</li>
                            <li onclick="this.classList.toggle('checked')">☐ Pilih 1 style</li>
                            <li onclick="this.classList.toggle('checked')">☐ Siapkan 10 gambar</li>
                            <li onclick="this.classList.toggle('checked')">☐ Buat 1 produk</li>
                            <li onclick="this.classList.toggle('checked')">☐ Upload & jual</li>
                        </ul>
                    </div>
                    <div class="important-box">
                        <h4>Pesan Penting:</h4>
                        <p>Checklist > niat doang. Action lebih penting dari sekadar rencana!</p>
                    </div>
                `
            },
            20: {
                title: "HALAMAN 20 — NEXT LEVEL",
                content: `
                    <h2>HALAMAN 20 — NEXT LEVEL</h2>
                    <h3>Setelah ini kamu bisa:</h3>
                    <div class="prompt-card">
                        <h4>1. Bikin brand anime sendiri</h4>
                        <p>Bangun identitas visual yang kuat dan konsisten</p>
                    </div>
                    <div class="prompt-card">
                        <h4>2. Naikkan harga</h4>
                        <p>Dengan reputasi dan portfolio yang bagus</p>
                    </div>
                    <div class="prompt-card">
                        <h4>3. Buat bundle</h4>
                        <p>Kombinasi produk untuk nilai lebih tinggi</p>
                    </div>
                    <div class="prompt-card">
                        <h4>4. Bangun komunitas</h4>
                        <p>Kumpulan fans dan pelanggan setia</p>
                    </div>
                    <div class="success-box">
                        <h4>🎌 Join Telegram: Anime Digital School</h4>
                        <p style="font-size: 1.2em; text-align: center; margin-top: 15px;">
                            Belajar • Konsisten • Cuan
                        </p>
                    </div>
                `
            }
        };
    }

    generatePromptCards(prompts) {
        return prompts.map((prompt, index) => `
            <div class="prompt-card">
                <h4>Prompt ${index + 1}</h4>
                <p>${prompt}</p>
            </div>
        `).join('');
    }

    setupNavigation() {
        const nav = document.querySelector('nav ul');
        for (let i = 1; i <= this.totalPages; i++) {
            const li = document.createElement('li');
            const button = document.createElement('button');
            button.textContent = `Halaman ${i}`;
            button.onclick = () => this.showPage(i);
            button.id = `nav-btn-${i}`;
            li.appendChild(button);
            nav.appendChild(li);
        }
    }

    setupEventListeners() {
        // Previous button
        document.getElementById('prev-btn').onclick = () => {
            if (this.currentPage > 1) {
                this.showPage(this.currentPage - 1);
            }
        };

        // Next button
        document.getElementById('next-btn').onclick = () => {
            if (this.currentPage < this.totalPages) {
                this.showPage(this.currentPage + 1);
            }
        };

        // PDF download button
        document.getElementById('pdf-btn').onclick = () => this.generatePDF();

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft' && this.currentPage > 1) {
                this.showPage(this.currentPage - 1);
            } else if (e.key === 'ArrowRight' && this.currentPage < this.totalPages) {
                this.showPage(this.currentPage + 1);
            }
        });
    }

    showPage(pageNum) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        // Show selected page
        const pageElement = document.getElementById(`page-${pageNum}`);
        if (pageElement) {
            pageElement.classList.add('active');
        } else {
            this.createPage(pageNum);
        }

        // Update navigation buttons
        document.querySelectorAll('nav button').forEach(btn => {
            btn.classList.remove('active');
        });
        document.getElementById(`nav-btn-${pageNum}`).classList.add('active');

        // Update current page
        this.currentPage = pageNum;

        // Update nav buttons state
        document.getElementById('prev-btn').disabled = pageNum === 1;
        document.getElementById('next-btn').disabled = pageNum === this.totalPages;

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    createPage(pageNum) {
        const main = document.querySelector('main');
        const pageData = this.pages[pageNum];
        
        const pageElement = document.createElement('div');
        pageElement.className = 'page';
        pageElement.id = `page-${pageNum}`;
        pageElement.innerHTML = pageData.content;
        
        main.appendChild(pageElement);
        pageElement.classList.add('active');
    }

    async generatePDF() {
        // Show loading state
        const pdfBtn = document.getElementById('pdf-btn');
        const originalText = pdfBtn.textContent;
        pdfBtn.textContent = '🔄 Generating PDF...';
        pdfBtn.disabled = true;

        try {
            // Create a temporary container for all pages
            const pdfContainer = document.createElement('div');
            pdfContainer.style.cssText = `
                position: fixed;
                left: -9999px;
                top: 0;
                width: 210mm;
                min-height: 297mm;
                background: white;
                padding: 20mm;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                color: #2d3436;
                line-height: 1.6;
            `;

            // Add header
            const header = document.createElement('div');
            header.innerHTML = `
                <h1 style="text-align: center; color: #6c5ce7; margin-bottom: 10px;">AI Anime Creator Starter Kit</h1>
                <h2 style="text-align: center; color: #a29bfe; margin-bottom: 30px;">Panduan Pemula Membuat Karakter Anime Original dengan AI</h2>
                <p style="text-align: center; font-style: italic; color: #636e72; margin-bottom: 40px;">© Anime Digital School by Asep Awaludin</p>
                <hr style="border: 2px solid #6c5ce7; margin: 30px 0;">
            `;
            pdfContainer.appendChild(header);

            // Add all pages content
            for (let i = 1; i <= this.totalPages; i++) {
                const pageData = this.pages[i];
                const pageDiv = document.createElement('div');
                pageDiv.style.cssText = `
                    page-break-after: always;
                    margin-bottom: 30px;
                `;
                pageDiv.innerHTML = pageData.content;
                pdfContainer.appendChild(pageDiv);
            }

            // Add footer
            const footer = document.createElement('div');
            footer.innerHTML = `
                <hr style="border: 2px solid #6c5ce7; margin: 30px 0;">
                <p style="text-align: center; font-style: italic; color: #636e72;">© Anime Digital School by Asep Awaludin</p>
            `;
            pdfContainer.appendChild(footer);

            document.body.appendChild(pdfContainer);

            // Use html2pdf library
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('p', 'mm', 'a4');

            // Get all content and convert to PDF
            const content = pdfContainer;
            await doc.html(content, {
                callback: function(doc) {
                    doc.save('AI-Anime-Creator-Starter-Kit.pdf');
                },
                x: 0,
                y: 0,
                width: 210,
                windowWidth: 210
            });

            // Remove temporary container
            setTimeout(() => {
                document.body.removeChild(pdfContainer);
            }, 1000);

            // Reset button
            pdfBtn.textContent = originalText;
            pdfBtn.disabled = false;

            alert('PDF berhasil didownload! 🎉');

        } catch (error) {
            console.error('PDF Generation Error:', error);
            pdfBtn.textContent = originalText;
            pdfBtn.disabled = false;
            alert('Terjadi kesalahan saat generating PDF. Silakan coba lagi.');
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AnimeCreatorApp();
});